<?php namespace PHRETS\Exceptions;

class AutomaticPaginationError extends \Exception
{

}
