<?php
date_default_timezone_set('America/New_York');
require_once("vendor/autoload.php");
function pr($data){echo '<pre>';print_r($data);echo '</pre>';}
global $rets;
function login(){
	$config = new \PHRETS\Configuration;
	$config->setLoginUrl('http://matrixrets.realcomponline.com/rets/Login.ashx')
	       ->setUsername('STOICAL')
	       ->setPassword('SSWI_4g6j8')
	       ->setRetsVersion('1.7.2');
	return new \PHRETS\Session($config);
}
$rets=login();

// If you're using Monolog already for logging, you can pass that logging instance to PHRETS for some additional
// insight into what PHRETS is doing.
//
// $log = new \Monolog\Logger('PHRETS');
// $log->pushHandler(new \Monolog\Handler\StreamHandler('php://stdout', \Monolog\Logger::DEBUG));
// $rets->setLogger($log);

$connect = $rets->Login();

function getMetadataObject($resource='Property'){
	global $rets;
	return $rets->GetMetadataObjects($resource);
}

function getListing($resource='Property',$class='RESI',$q='Matrix_Unique_ID=0+',$offset=0,$limit=2){
	global $rets;
	return $results = $rets->Search($resource, $class, $q,['Format' => 'COMPACT-DECODED','Limit'=>$limit,'Offset'=>$offset]);
}


function getPropertyImages($listing_id='952807',$resource='Property',$type='Photo'){
	global $rets;
	return $rets->GetObject($resource, $type, $listing_id);
}


//end Listing
/*$finish = $rets->Disconnect();*/





