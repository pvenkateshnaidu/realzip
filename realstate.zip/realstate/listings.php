<?php
 require_once 'k.php';
 
 
 if(isset($_REQUEST['searchKey'])&&!empty($_REQUEST['searchKey']))
 {
	 $city=$_REQUEST['searchKey'];
 }
  if(isset($_REQUEST['beds'])&&!empty($_REQUEST['beds']))
 {
	 $tbeds=$_REQUEST['beds'];
	 if($tbeds=='-1')
	 {
		 $tbeds='';
	 }
 }else{
	  $tbeds='';
 }
   if(isset($_REQUEST['bathr'])&&!empty($_REQUEST['bathr']))
 {
	 $bathr=$_REQUEST['bathr'];
	 if($bathr=='-1')
	 {
		 $bathr='';
	 }
 }else{
	  $bathr='';
 }
 
 if(!empty($city))
 {
	 $html='(Matrix_Unique_ID=0+),(City='.$city.')';
	 if(!empty($tbeds) )
	 {
		 $html.=',(BedsTotal='.$tbeds.')';
	 
	 }
	 	 if(!empty($bathr) )
	 {
		 $html.=',(BathsFull='.$bathr.')';
	 
	 }
	 
	$results=getListing($resource='Property',$class='RESI',$q=$html,$offset=0,$limit=10);
	
	 
 }else{
	$results=getListing($resource='Property',$class='RESI',$q='(Matrix_Unique_ID=0+),(City=plymouth)',$offset=0,$limit=20); 
 }

$propertyCount=$results->count();

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
<title>Virtual Real Estate Services </title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/idea_homes._icons.css">
<link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="css/animate.min.css">
<link rel="stylesheet" type="text/css" href="css/settings.css">
<link rel="stylesheet" type="text/css" href="css/cubeportfolio.min.css">
<link rel="stylesheet" type="text/css" href="css/bootsnav.css">
<link rel="stylesheet" type="text/css" href="css/range-Slider.min.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<link href="css/scrolling-nav.css" rel="stylesheet">

</head>

<body  data-spy="scroll" data-target=".navbar-fixed-top">

<!-- LOADER -->

<!--===== #/LOADER =====-->


<!--===== BACK TO TOP =====-->
<a href="#" class="back-to"><i class="icon-arrow-up2"></i></a>
<!--===== #/BACK TO TOP =====-->


<!--===== HEADER =====-->
<header id="main_header">
  <!--===== HEADER TOP =====-->
  <div id="header-top">
    <div class="container">
      <div class="row">
        <div class="col-md-4 col-sm-4 col-xs-12">
          <p class="p-font-15 p-white">We are Best in Town With 40 years of Experience.</p>
        </div>
        <div class="col-md-8 col-sm-8 col-xs-12 text-right">
          <div class="header-top-links">
            <ul>
              <!--<li><a href="favorite_properties.html"><i class="icon-heart2"></i>Favorites</a></li>-->
              
              <li><a href="contact_us.html"><i class="icon-icons215"></i>Submit Property</a></li>
              <li class="af-line"></li>
              <li><a href="contact_us.html"><i class="icon-icons215"></i>My Property</a></li>
              <li><a href="contact_us.html" class="header-login"><i class="icon-icons179"></i>Login / Register</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--===== #/HEADER TOP =====--> 
  <!--===== HEADER BOTTOM =====-->
  <div id="header-bottom">
    <div class="container">
      <div class="row">
        <div class="col-md-2 hidden-xs hidden-sm"><a href="index.html"><img src="images/logo-white.png" alt="logo"/></a></div>
        <div class="col-md-10 col-sm-12 col-xs-12">
          <div class="get-tuch text-left top20">
            <i class="icon-telephone114"></i>
            <ul>
              <li>
                <h4>Phone Number</h4>
              </li>
              <li>
                <p>+(313) 510-2091</p>
              </li>
            </ul>
          </div>
          <div class="get-tech-line top20"><img src="images/get-tuch-line.png" alt="line"/></div>
          <div class="get-tuch text-left top20">
            <i class="icon-icons74"></i>
            <ul>
              <li>
                <h4>34841 Mound Road, Ste 244 ,
</h4>
              </li>
              <li>
                <p>Sterling Heights, MI 48310, America</p>
              </li>
            </ul>
          </div>
          <div class="get-tech-line top20"><img src="images/get-tuch-line.png" alt="line"/></div>
          <div class="get-tuch text-left top20">
            <i class=" icon-icons142"></i>
            <ul>
              <li>
                <h4>Email Address</h4>
              </li>
              <li>
                <p><a href="#">Colette@virtualrealestatesvcs.com</a></p>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--===== #/HEADER BOTTOM =====--> 
  <!--===== NAV-BAR =====-->
  <nav class="navbar navbar-default navbar-sticky bootsnav">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="social-icons text-right">
            <ul class="socials">
              <li><a href="#"><i class="fa fa-facebook"></i></a></li>
              <li><a href="#"><i class="fa fa-twitter"></i></a></li>
              <li><a href="#"><i class="fa fa-instagram"></i></a></li>
              <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
            </ul>
          </div>
          <!-- Start Header Navigation -->
          <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
            <i class="fa fa-bars"></i></button>
            <a class="navbar-brand sticky_logo" href="index.html"><img src="images/logo-white.png" class="logo" alt=""></a>
          </div>
          <!-- End Header Navigation --> 
          <!-- Collect the nav links, forms, and other content for toggling -->
          <div class="collapse navbar-collapse" id="navbar-menu">
            <ul class="nav navbar-nav" data-in="fadeInDown" data-out="fadeOutUp">
             
                       <li><a href="index.html">Home</a></li>
					     <li><a href="about-us.html">About Us</a></li>
						 <li><a href="agents.html">Agents</a></li>
                         <li><a href="testimonials.html">Testimonials</a></li>
						 <li><a href="listings.php">Listings</a></li>
			       <li><a href="contact_us.html">Contact Us</a></li>
                    </ul>
          </div>
        </div>
      </div>
    </div>
  </nav>
  <!--===== #/NAV-BAR =====--> 
</header>

<!-- PAGE TITLE -->
<div class="page-title page-main-section">
  <div class="container padding-bottom-top-120 text-uppercase text-center">
    <div class="main-title">
      <h1>Listings</h1>
      <h5>Always Expect the Best!...Quality Services at a Professional Level</h5>
      <div class="line_4"></div>
      <div class="line_5"></div>
      <div class="line_6"></div>
      <a href="index.html">home</a><span><i class="fa fa-angle-double-right" aria-hidden="true"></i></span><a href="listings.html">Listing Properties</a> 
    </div>
  </div>
</div>
<!-- PAGE TITLE -->

<!-- LISTING STYLE - 2 -->
<section class="property-query-area property-page-bg padding">
  <div class="container">
  <form method="GET" id="search-form" action="<?php echo $_SERVER['PHP_SELF'];?>">
	<div class="row">
      <div class="col-md-12 bottom40">
        <h2 class="text-uppercase">Advanced <span class="color_red">Search</span></h2>
         <div class="line_1"></div>
         <div class="line_2"></div>
      
      </div>
    </div>
    <div class="row">
      
        <div class="col-md-3 col-sm-3">
          <div class="single-query form-group frmSearch">
            <label>Keyword</label>
            <input class="keyword-input" name="searchKey" id="search-box" placeholder="City" required type="text" value="<?php if(isset($_REQUEST['searchKey'])) echo $_REQUEST['searchKey']; ?>">
			<div id="suggesstion-box"></div>
          </div>
	
        </div>
    
     
    </div>
    <div class="row search-2">
     
        <div class="col-md-3 col-sm-6">
          <div class="row">
            <div class="col-md-6 col-sm-6">
              <div class="single-query form-group">
                <div class="intro">
                  <label>Bed Room</label>
                  <select name="beds">
                    <option value="-1" class="active">Any</option>
                    <option value="1" <?php if(isset($_REQUEST['beds'])&&$_REQUEST['beds']==1) echo "selected" ?>>1</option>
                    <option value="2" <?php if(isset($_REQUEST['beds'])&&$_REQUEST['beds']==2) echo "selected" ?>>2</option>
                    <option value="3" <?php if(isset($_REQUEST['beds'])&&$_REQUEST['beds']==3) echo "selected" ?>>3</option>
                    <option value="4" <?php if(isset($_REQUEST['beds'])&&$_REQUEST['beds']==4) echo "selected" ?>>4</option>
                    <option value="5" <?php if(isset($_REQUEST['beds'])&&$_REQUEST['beds']==5) echo "selected" ?>>5</option>
                    <option value="6" <?php if(isset($_REQUEST['beds'])&&$_REQUEST['beds']==6) echo "selected" ?>>6</option>
                  </select>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-sm-6">
              <div class="single-query form-group">
                <div class="intro">
                  <label>Bath Room</label>
                  <select name="bathr">
				   <option value="-1" class="active">Any</option>
                       <option value="1" <?php if(isset($_REQUEST['bathr'])&&$_REQUEST['bathr']==1) echo "selected" ?>>1</option>
                    <option value="2" <?php if(isset($_REQUEST['bathr'])&&$_REQUEST['bathr']==2) echo "selected" ?>>2</option>
                    <option value="3" <?php if(isset($_REQUEST['bathr'])&&$_REQUEST['bathr']==3) echo "selected" ?>>3</option>
                    <option value="4" <?php if(isset($_REQUEST['bathr'])&&$_REQUEST['bathr']==4) echo "selected" ?>>4</option>
                    <option value="5" <?php if(isset($_REQUEST['bathr'])&&$_REQUEST['bathr']==5) echo "selected" ?>>5</option>
                    <option value="6" <?php if(isset($_REQUEST['bathr'])&&$_REQUEST['bathr']==6) echo "selected" ?>>6</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div class="col-md-2 col-sm-6 col-xs-12 text-right">
          <div class="query-submit-button top10">
            <input class="btn_fill" value="Search" type="submit">
          </div>
        </div>
    
    </div>

  </form>
    </div>
  </div>
</section>
<!--LISTING STYLE- 2 -->




<!-- LISTING -->
<section id="listings" class="padding">
  <div class="container">
    <div class="row bottom40">
      <div class="col-xs-12">
        <h2 class="uppercase">PROPERTY <span class="color_red">LISTINGS</span></h2>
        <div class="line_1"></div>
        <div class="line_2"></div>
        <div class="line_3"></div>
        <p class="heading_space">We have Properties in these Areas View a list of Featured Properties.</p>
      </div>
    </div>
    <div class="row bottom30">
    

      </div>
        <?php if($propertyCount>0){
	        for($i=0;$i<$propertyCount;$i++){
		        $property=json_decode($results->offsetGet($i),true);
		        if(!empty($property)){
			        $photos=getPropertyImages($property['Matrix_Unique_ID']);
			        $img='images/property-listing-2.jpg';
			        $n=1;
					$photosArray='';
			        foreach($photos as $photo) {
				        if ($photo->getContentId()) {
				            $pth=dirname(__FILE__);
					        $img='photos_residential/'.$property['Matrix_Unique_ID'].'-'.$n.'.jpg';
					        if(!file_exists($pth.'/'.$img)){
						        file_put_contents($img, $photo->getContent());
                            }
                           $photosArray[]=$img;
				        }
				        $n++;
			        }
					 
					?>
                    <div class="col-md-4 col-sm-4 col-xs-12">
                        <div class="property_item heading_space">
                            <div class="image">
                                <img src="<?php echo $photosArray[0];?>" alt="listin" class="img-responsive">
                           
                                <div class="feature"><span class="tag">Featured</span></div>
                                <div class="price"><span class="tag">For Sale</span></div>
                                <div class="overlay">
                                    <div class="centered"><a class="link_arrow white_border" href="property_details.php?id=<?php echo $property['Matrix_Unique_ID']; ?>">View Detail</a></div>
                                </div>
                                <div class="property_meta">
                                    <span><i class="fa fa-object-group"></i><?php echo $property['sqftTotal'];?> sq ft </span>
                                    <span><i class="fa fa-bed"></i><?php echo $property['BedsTotal'];?></span>
                                    <span><i class="fa fa-bath"></i><?php echo $property['BathsFull'];?> Bathroom</span>
                                </div>
                            </div>
                            <div class="proerty_content">
                                <div class="proerty_text">
                                  <!--  <a href="property_details_1.html"><?php echo $property['ListOfficeName'];?></a> -->
                                    <h3><span class="bottom10"><?php echo $property['UnparsedAddress'].' '.$property['CountyOrParish'].', '.$property['StateOrProvince']?></span></h3>
                                    <p><strong>$<?php echo number_format($property['ListPrice']);?></strong></p>
                                </div>
                                <div class="favroute clearfix">
                                  
                                    <ul class="pull-right">
                                        <li><a href="#."><i class="icon-video"></i></a></li>
                                        <li><a href="#."><i class="icon-like"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php }
	        }
        }else{?>
            <h4>No Property Found.</h4>
        <?php }?>

        <div class="project1 clearfix">
          <div class="col-md-12 col-sm-12 col-xs-12 padding-left-0 project-images">
            <div class="gri">
              <figure class="effect-layla">
                <img src="images/b-d-property-2.jpg" alt="img"/>
                <figcaption> </figcaption>
              </figure>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-12 project-owl-slidee padding-left-0 project-owl-slideee">
              <div class="item background-color-white">
                <h4>Residential Project-d05</h4>
                <div class="small-title">
                  <div class="line1"></div>
                  <div class="line2"></div>
                  <div class="clearfix"></div>
                </div>
                <div class="client-loc">
                  <p><span>Client:</span> Bryan Doe Joe</p>
                  <p><span>Location:</span> Mountain Line CA 62548</p>
                  <p><span>Value:</span> $15,000</p>
                </div>
                <a href="#." class="link_arrow">read more</a> 
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
   </div>
</section>
<!--LISTING FILTER -->



<!-- CONTACT -->
<section id="contact" class="bg-color-red">
  <div class="container">
    <div class="row">
      <div class="col-md-4 col-sm-4 col-xs-12 text-center">
        <div class="get-tuch">
          <i class="icon-telephone114"></i>
          <ul>
            <li><h4>Phone Number</h4></li>
            <li><p>+1 (313) 510-2091</p></li>
          </ul>
        </div>
      </div>
      <div class="col-md-4 col-sm-4 col-xs-12 text-center">
        <div class="get-tuch">
          <i class="icon-icons74"></i>
          <ul>
            <li>
              <h4>34841 Mound Road, Ste 244
      ,</h4>
            </li>
            <li><p>Sterling Heights, MI 48310, America</p></li>
          </ul>
        </div>
      </div>
      <div class="col-md-4 col-sm-4 col-xs-12 text-center">
        <div class="get-tuch">
          <i class="icon-icons142"></i>
          <ul>
            <li><h4 class="p-font-17">Email Address</h4></li>
            <li><a href="#."><p>Colette@virtualrealestatesvcs.com</p></a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>
<footer id="footer" class="footer divider layer-overlay overlay-dark-8">
    <div class="container pt-70">
        <div class="row border-bottom">
            <div class="col-sm-6 col-md-3">
                <div class="widget dark"> <img class="mt-5 mb-20" alt="" src="images/logo-white.png">
                    <p>It is our goal to go above and beyond your expected needs and comfort. With our years of experience and knowledge, we calm the emotions of Real Estate decisions while you decide on the place where lifetime memories will happen.</p>
                </div>
            </div>
            <div class="col-sm-6 col-md-3">
                <div class="widget dark">
                    <h4 class="widget-title">Quick Links</h4>
                    <div class="small-title">
                        <div class="line1 background-color-white"></div>
                        <div class="line2 background-color-white"></div>
                        <div class="clearfix"></div>
                    </div>
                    <ul class="list angle-double-right list-border">
                        <li><a class="page-scroll" href="#menu">Home</a></li>
					     <li><a class="page-scroll" href="#wellcome">About</a></li>
						 <li><a class="page-scroll" href="#estimate">Let Me Work For You</a></li>
                         <li><a class="page-scroll" href="#image-text">Testimonials</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-sm-6 col-md-3">
                <div class="widget dark">
                    <h4 class="widget-title ">Connect With Colette</h4>
                    <div class="small-title">
                        <div class="line1 background-color-white"></div>
                        <div class="line2 background-color-white"></div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="widget dark">
                    <h5 class="widget-title mb-10"> +(313) 510-2091</h5>
                   
                </div>
				<ul class="socials">
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                        <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                        <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="col-sm-6 col-md-3">
                <div class="widget dark">
                    <h4 class="widget-title">Contact</h4>
                    <div class="small-title">
                        <div class="line1 background-color-white"></div>
                        <div class="line2 background-color-white"></div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="opening-hourse">
                        <p>34841 Mound Road, Ste 244
      Sterling Heights, MI 48310
</p>
                    <ul class="list-inline mt-5">
                       <li class="m-0 pl-10 pr-10"> <i class="fa fa-envelope-o text-theme-color-2 mr-5"></i> <a class="text-gray" href="#">Colette@virtualrealestatesvcs.com</a> </li>
                        <li class="m-0 pl-10 pr-10"> <i class="fa fa-globe text-theme-color-2 mr-5"></i> <a class="text-gray" href="#"> http://m.mvcard.me/colette</a> </li>
                    </ul>
					
                    </div>
                </div>
            </div>
        </div>
        
    </div>
    <div class="footer-bottom bg-black-333">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-5">
                    <p class="font-11 text-black-777 m-0 copy-right">Copyright; 2017 <a href="#"><span class="color_red">webmobilez.com</span></a>. All Rights Reserved</p>
                </div>
                <div class="col-md-6 col-sm-7 text-right">
                    <div class="widget no-border m-0">
                        <ul class="list-inline sm-text-center mt-5 font-12">
                            <li> <a href="#">LEASE</a> </li>
                            <li>|</li>
                            <li> <a href="#">BUY</a> </li>
                            <li>|</li>
                            <li> <a href="#">SELL</a> </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
 <!-- #/FOOTER -->
<script src="js/jquery.2.2.3.min.js"></script>

<script>

$(document).ready(function(){
	
	$("#search-box").keyup(function(){
		$.ajax({
		type: "POST",
		url: "readCountry.php",
		data:'keyword='+$(this).val(),
		beforeSend: function(){
			$("#search-box").css("background","#FFF url(LoaderIcon.gif) no-repeat 165px");
		},
		success: function(data){
			$("#suggesstion-box").show();
			$("#suggesstion-box").html(data);
			$("#search-box").css("background","#FFF");
		}
		});
	});
	
});

function selectCountry(val) {
$("#search-box").val(val);
$("#suggesstion-box").hide();
}

</script>

<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.easing.min.js"></script>
<script src="js/scrolling-nav.js"></script>
<script src="js/jquery.appear.js"></script>
<script src="js/jquery.parallax-1.1.3.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/cubeportfolio.min.js"></script>
<script src="js/range-Slider.min.js"></script>
<script src="js/selectbox-0.2.min.js"></script>
<script src="js/bootsnav.js"></script>
<script src="js/zelect.js"></script>
<script src="js/jquery.themepunch.tools.min.js"></script>
<script src="js/jquery.themepunch.revolution.min.js"></script>
<script src="js/revolution.extension.layeranimation.min.js"></script>
<script src="js/revolution.extension.navigation.min.js"></script>
<script src="js/revolution.extension.parallax.min.js"></script>
<script src="js/revolution.extension.slideanims.min.js"></script>
<script src="js/revolution.extension.video.min.js"></script>
<script src="js/functions.js"></script>



</body>
</html>