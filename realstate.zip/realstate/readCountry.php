<?php
require_once("dbcontroller.php");
$db_handle = new DBController();
if(!empty($_POST["keyword"])) {
$query ="SELECT * FROM cities_extended WHERE city like '" . $_POST["keyword"] . "%'  group by city";
$result = $db_handle->runQuery($query);
if(!empty($result)) {
?>
<ul id="country-list">
<?php
foreach($result as $country) {
?>
<li onClick="selectCountry('<?php echo $country["city"]; ?>');"><?php echo $country["city"]; ?></li>
<?php } ?>
</ul>
<?php } } ?>